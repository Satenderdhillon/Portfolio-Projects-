import pyodbc
import tkinter as tk
from tkinter import messagebox

# Establish connection to the database
try:
    # Connecting to the AdventureWorksLT2019 database using pyodbc
    conn = pyodbc.connect(
        'DRIVER={SQL Server};'
        'SERVER=DESKTOP-KC499PE\SATURN;'  # Replace with your server name
        'DATABASE=AdventureWorksLT2019;'  # The database I worked on for this project
        'UID=sa;'  # Replace with your SQL Server username
        'PWD=jimmy'  # Replace with your SQL Server password
    )
    print("Connection successful.")
except pyodbc.Error as e:
    # Handle connection errors gracefully
    print("Error in connection:", e)
    exit()

# Function to fetch and return product categories
def get_product_categories():
    """
    Fetch and return the list of product categories from the PRODUCTVIEWASSN view.
    - PRODUCTVIEWASSN: A view I created in my very first class to display ProductCategoryID and Name.
    """
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM PRODUCTVIEWASSN")  # Querying the view
        categories = cursor.fetchall()  # Fetching all rows from the result
        return categories
    except pyodbc.Error as e:
        # Show error if fetching categories fails
        messagebox.showerror("Error", f"Error fetching product categories: {e}")
        return []

# Function to execute the stored procedure
def execute_stored_procedure(product_category_id, percent):
    """
    Call the stored procedure [dbo].[PYTHONSATENDER] to update product details.
    - product_category_id: ID of the product category to update.
    - percent: The percentage multiplier for adjustments (e.g., 1.02 for 2% increase).
    """
    cursor = conn.cursor()
    try:
        # Executing the stored procedure with parameters
        cursor.execute("EXEC PYTHONSATENDER ?, ?", (product_category_id, percent))
        conn.commit()  # Commit changes to the database
        # Show success message
        messagebox.showinfo("Success", f"Stored procedure executed successfully for ProductCategoryID: {product_category_id} with Percent: {percent}.")
    except pyodbc.Error as e:
        # Handle errors during stored procedure execution
        messagebox.showerror("Error", f"Error executing stored procedure: {e}")

# Function to handle form submission
def submit_form():
    """
    Collect data from input fields, convert percentage to multiplier, and execute the stored procedure.
    - Allows user to input a simple percentage without manual conversion.
    """
    try:
        # Get inputs from the GUI fields
        product_category_id = int(category_id_entry.get())  # Product Category ID input
        percentage = float(percent_entry.get())  # Percent input as a whole number or decimal
        
        # Convert percentage to multiplier
        multiplier = 1 + (percentage / 100)  # This line allows simple percentage input

        execute_stored_procedure(product_category_id, multiplier)  # Call the stored procedure with the multiplier
    except ValueError:
        # Show error if input values are invalid
        messagebox.showerror("Invalid Input", "Please enter valid numeric values for Product Category ID and Percent.")

# Create the GUI application
root = tk.Tk()
root.title("Database Application")  # Application title
root.geometry("500x400")  # Window size
root.config(bg="lightblue")  # Background color

# Title Label
title_label = tk.Label(root, text="Database Update Application", font=("Arial", 16, "bold"), bg="lightblue")
title_label.pack(pady=10)

# Product Categories Label and Display
categories_label = tk.Label(root, text="Available Product Categories:", font=("Arial", 12), bg="lightblue")
categories_label.pack()

# Fetch and display product categories from the view
categories = get_product_categories()
categories_text = "\n".join([f"ID: {cat.ProductCategoryID}, Name: {cat.Name}" for cat in categories])  # Formatting categories for display
categories_display = tk.Text(root, height=5, width=50, bg="white", state="normal")  # Text widget for displaying categories
categories_display.insert("1.0", categories_text)  # Insert categories into the widget
categories_display.configure(state="disabled")  # Make the widget read-only
categories_display.pack(pady=10)

# Input Fields for Product Category ID
category_id_label = tk.Label(root, text="Enter Product Category ID:", font=("Arial", 12), bg="lightblue")
category_id_label.pack(pady=5)
category_id_entry = tk.Entry(root, font=("Arial", 12), width=30)  # Input field for Product Category ID
category_id_entry.pack(pady=5)

# Input Fields for Percent
percent_label = tk.Label(root, text="Enter Percent:", font=("Arial", 12), bg="lightblue")
percent_label.pack(pady=5)
percent_entry = tk.Entry(root, font=("Arial", 12), width=30)  # Input field for Percent
percent_entry.pack(pady=5)

# Submit Button
submit_button = tk.Button(root, text="Update Database", font=("Arial", 12, "bold"), bg="green", fg="white", command=submit_form)
submit_button.pack(pady=20)

# Run the application
root.mainloop()
