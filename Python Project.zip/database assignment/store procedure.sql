USE [AdventureWorksLT2019]
GO

/****** Object:  StoredProcedure [dbo].[PYTHONSATENDER]    Script Date: 2024-12-03 1:32:41 PM ******/
DROP PROCEDURE [dbo].[PYTHONSATENDER]
GO

/****** Object:  StoredProcedure [dbo].[PYTHONSATENDER]    Script Date: 2024-12-03 1:32:41 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		SATENDER SINGH DHILLON
-- Create date: 2024-11-21
-- Description:	Store procedure for database application project--
-- =============================================
CREATE PROCEDURE [dbo].[PYTHONSATENDER] @ProductCategoryID INT, @Percent numeric(5,2)
AS
SELECT @ProductCategoryID
SELECT @Percent

-- Create temp table to test and ensure records return valid data for update
CREATE TABLE #ProductIDPython (
    CategoryID INT,
    StandardCost Money,
    Weight Decimal(8,2),
    SizeCHAR NVARCHAR(5),
    SizeDecimal Numeric(5,2)
)

BEGIN
    -- BEGIN UPDATE TO TEMP TABLE FOR VERIFICATION WITH DATASET

    BEGIN
        INSERT INTO #ProductIDPython (CategoryID, StandardCost, Weight, SizeCHAR, SizeDecimal)
        SELECT ProductCategoryID, StandardCost * @Percent, Weight * @Percent, Size,TRY_CAST ([size]AS numeric(5,2)) * @Percent
        FROM SalesLT.Product
        WHERE ProductCategoryID = @ProductCategoryID

    -- END UPDATE TO TEMP TABLE FOR VERIFICATION WITH DATASET
      UPDATE #ProductIDPython SET SizeCHAR = TRY_CAST (SizeDecimal AS CHAR (5))

      END
            
            SELECT ProductCategoryID,StandardCost,Weight,Size
            FROM SalesLT.Product
            WHERE (ProductCategoryID = @ProductCategoryID)


            SELECT * FROM #ProductIDPython

---- updating the  live table ----
                  UPDATE SalesLT.Product
                  SET StandardCost = #ProductIDPython.StandardCost ,
                  Weight = #ProductIDPython.Weight,
                  Size = #ProductIDPython.SizeCHAR
                  FROM SalesLT.Product INNER JOIN
                  #ProductIDPython ON SalesLT.Product.ProductID = #ProductIDPython.CategoryID
                  AND SalesLT.Product.ProductCategoryID = #ProductIDPython.CategoryID


END
GO

